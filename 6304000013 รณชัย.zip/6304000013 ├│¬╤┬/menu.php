<?php
echo '<a href="/page1.php">PAGE 1</a> -
<a href="/page2.php">PAGE 2</a> -
<a href="/page3.php">PAGE 3</a> ';
?>
