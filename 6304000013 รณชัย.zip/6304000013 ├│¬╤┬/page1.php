<html>
<body>
<div class="menu">
<?php include 'menu.php';?>
</div>

<h1>Welcome to page 1</h1>


</body>
</html>